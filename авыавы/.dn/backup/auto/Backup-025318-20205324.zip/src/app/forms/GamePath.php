<?php
namespace app\forms;

use bundle\windows\Registry;
use bundle\windows\Windows;
use php\lib\fs;
use std, gui, framework, app;


class GamePath extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {
        $game_path = $this->fileChooser->execute(); // НЕ ТРОГАТЬ
        $this->edit->text = $game_path;
        if(fs::isFile($game_path)) // НЕ ТРОГАТЬ
        {
         $this->ini->set('game_path', $game_path, 'settings');
         app()->hideForm('GamePath');
        app()->showForm('MainForm'); 
        }
        else UXDialog::show('Выберите путь к игре!'); // НЕ ТРОГАТЬ
    }
    

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $game_path = $this->ini->get(); // НЕ ТРОГАТЬ
        if($game_path) app()->hideForm('GamePath'); app()->showForm('MainForm'); // НЕ ТРОГАТЬ
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown(); // НЕ ТРОГАТЬ  
    }

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('GamePath'); // НЕ ТРОГАТЬ
        app()->showForm('MainForm'); // НЕ ТРОГАТЬ
    }


}
